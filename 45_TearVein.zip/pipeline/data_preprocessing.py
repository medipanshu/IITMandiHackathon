import os
import cv2
import numpy as np
import torch
import random
import glob
from PIL import Image
import albumentations as A
from albumentations.pytorch import ToTensorV2
from torch.utils.data import Dataset, DataLoader
from ultralytics import YOLO

def set_seed(seed=42):
    """Set seeds for reproducibility"""
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

class VesselDataset(Dataset):
    def __init__(self, img_dir, mask_dir, transform=None, yolo_model=None, apply_preprocessing=True):
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.transform = transform
        self.yolo_model = yolo_model
        self.apply_preprocessing = apply_preprocessing
        
        # Get all image files
        self.images = sorted(glob.glob(os.path.join(img_dir, "*.*")))
        self.masks = sorted(glob.glob(os.path.join(mask_dir, "*.*")))
        
    def __len__(self):
        return len(self.images)
    
    def apply_clahe_to_green_channel(self, image):
        """Apply CLAHE to the green channel only"""
        # Extract channels
        b, g, r = cv2.split(image)
        
        # Create CLAHE object
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        
        # Apply CLAHE to green channel
        g_clahe = clahe.apply(g)
        
        # Merge channels back
        return cv2.merge([b, g_clahe, r])
    
    def preprocess_image(self, image):
        """Apply preprocessing to the image"""
        if not self.apply_preprocessing:
            return image
            
        # Apply CLAHE to green channel
        image = self.apply_clahe_to_green_channel(image)
        
        return image
    
    def apply_yolo_segmentation(self, image):
        """Apply YOLOv8 segmentation to extract sclera region"""
        if self.yolo_model is None:
            return image
        
        # Store original dimensions
        original_h, original_w = image.shape[:2]
        
        # For very large images, we may need to resize for memory efficiency with YOLOv8
        # YOLOv8 typically works well with images around 640-1280px
        yolo_input_size = 1280  # A reasonable size that YOLOv8 can handle efficiently
        
        # Calculate scale factor while maintaining aspect ratio
        scale = min(yolo_input_size / original_w, yolo_input_size / original_h)
        yolo_w = int(original_w * scale)
        yolo_h = int(original_h * scale)
        
        # Resize for YOLOv8 processing
        yolo_image = cv2.resize(image, (yolo_w, yolo_h))
            
        # Run inference with YOLOv8
        results = self.yolo_model(yolo_image)
        
        # Extract segmentation mask
        if len(results) > 0 and hasattr(results[0], 'masks') and results[0].masks is not None:
            # Get the first segmentation mask (assuming there's only one sclera)
            mask = results[0].masks.data[0].cpu().numpy()
            
            # Resize mask back to original image dimensions
            mask = cv2.resize(mask.astype(np.float32), (original_w, original_h))
            
            # Apply mask to original image
            masked_image = image.copy()
            masked_image = masked_image * mask[:, :, np.newaxis]
            return masked_image.astype(np.uint8)
        
        # Return original image if no masks found
        return image
        
    def __getitem__(self, idx):
        # Load image and mask
        img_path = self.images[idx]
        mask_path = self.masks[idx]

        # Read image and mask
        image = cv2.imread(img_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
        if mask is None:  # Try PIL if OpenCV fails
            mask = np.array(Image.open(mask_path).convert('L'))

        # Apply YOLOv8 segmentation if model is provided
        if self.yolo_model is not None:
            image = self.apply_yolo_segmentation(image)

        # Apply preprocessing
        image = self.preprocess_image(image)

        # Apply transformations
        if self.transform is not None:
            augmented = self.transform(image=image, mask=mask)
            image = augmented['image']
            mask = augmented['mask']

        # Convert mask to binary (0 or 1)
        if isinstance(mask, np.ndarray):
            mask = (mask > 0).astype(np.float32)
            mask = np.expand_dims(mask, axis=0)  # Add channel dimension
        else:
            mask = (mask > 0).float()
            mask = mask.unsqueeze(0)  # Add channel dimension

        # Ensure mask has the right shape (1, H, W)
        if isinstance(mask, torch.Tensor):
            if len(mask.shape) != 3 or mask.shape[0] != 1:
                mask = mask.unsqueeze(0)

        return image, mask

def get_transforms(phase, input_size=512):
    """
    Get image transformations for training or validation
    
    Args:
        phase: 'train' or 'val'
        input_size: Size to resize images to for model input
    """
    if phase == "train":
        return A.Compose([
            # Fixed resize to ensure all images have exactly the same dimensions
            A.Resize(height=input_size, width=input_size, always_apply=True),
            # Apply augmentations
            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.5),
            A.RandomRotate90(p=0.5),
            A.ShiftScaleRotate(shift_limit=0.1, scale_limit=0.1, rotate_limit=15, p=0.7),
            # Normalize for pretrained models
            A.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
            ToTensorV2(),
        ])
    else:
        return A.Compose([
            # Fixed resize for validation as well
            A.Resize(height=input_size, width=input_size, always_apply=True),
            A.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
            ToTensorV2(),
        ])
        
def load_yolo_model(model_path="/storage/shagun/hackathon/vein_segmentation/yolov8m_scratch/weights/yolov8-m.pt"):
    """Load YOLOv8m-seg model for sclera segmentation"""
    try:
        if model_path and os.path.exists(model_path):
            model = YOLO(model_path)
        else:
            # Use default YOLOv8m-seg model if path not provided or invalid
            model = YOLO("yolov8m-seg.pt")
        return model
    except Exception as e:
        print(f"Error loading YOLO model: {e}")
        print("Continuing without YOLO segmentation...")
        return None

def create_data_loaders(train_dataset, val_dataset, batch_size, num_workers=0):
    """
    Create data loaders for training and validation
    
    Args:
        train_dataset: Training dataset
        val_dataset: Validation dataset
        batch_size: Batch size
        num_workers: Number of workers for data loading (set to 0 to avoid multiprocessing)
    """
    # Create data loaders
    train_loader = DataLoader(
        train_dataset, 
        batch_size=batch_size, 
        shuffle=True, 
        num_workers=0,  # Force no multiprocessing
        pin_memory=True if torch.cuda.is_available() else False,
        persistent_workers=False  # Must be False when num_workers=0
    )
    
    val_loader = DataLoader(
        val_dataset, 
        batch_size=batch_size, 
        shuffle=False, 
        num_workers=0,  # Force no multiprocessing
        pin_memory=True if torch.cuda.is_available() else False,
        persistent_workers=False  # Must be False when num_workers=0
    )
    
    return train_loader, val_loader

def create_datasets(train_img_dir, train_mask_dir, val_img_dir, val_mask_dir, 
                   yolo_model=None, input_size=512):
    """
    Create datasets for training and validation
    
    Args:
        train_img_dir: Directory containing training images
        train_mask_dir: Directory containing training masks
        val_img_dir: Directory containing validation images
        val_mask_dir: Directory containing validation masks
        yolo_model: YOLO model for segmentation
        input_size: Input size for transformations
    """
    # Get transforms
    train_transform = get_transforms("train", input_size=input_size)
    val_transform = get_transforms("val", input_size=input_size)
    
    # Create datasets
    train_dataset = VesselDataset(
        train_img_dir, 
        train_mask_dir, 
        transform=train_transform, 
        yolo_model=yolo_model
    )
    
    val_dataset = VesselDataset(
        val_img_dir, 
        val_mask_dir, 
        transform=val_transform, 
        yolo_model=yolo_model
    )
    
    return train_dataset, val_dataset

