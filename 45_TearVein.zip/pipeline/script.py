import os
import numpy as np
import cv2
import torch
import matplotlib.pyplot as plt
from PIL import Image
import argparse
# from AnglePred.src.main import 
from ultralytics import YOLO
import subprocess

# Simple call, waits for completion
subprocess.call(['python', 'other_script.py', 'arg1', 'arg2'])


# Import your functions for model loading and data preprocessing
from data_preprocessing import load_yolo_model, get_transforms
from model import load_model

def preprocess_image(image_path, yolo_model, input_size=512):
    """
    Preprocess a single image using the YOLOv8 model and transformations
    """
    # Read image
    image = cv2.imread(image_path)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
    # Apply YOLOv8 model for preprocessing (sclera segmentation)
    yolo_results = yolo_model(image)
    
    # Process YOLO results
    processed_image = process_yolo_results(image, yolo_results)
    
    # Get transforms for validation (no augmentations)
    transform = get_transforms("val", input_size=input_size)
    
    # Apply transforms
    if transform:
        transformed = transform(image=processed_image)
        processed_tensor = transformed["image"]
        # Add batch dimension
        processed_tensor = processed_tensor.unsqueeze(0)
    else:
        # Fallback if no transform is provided
        processed_tensor = torch.from_numpy(processed_image.transpose(2, 0, 1)).float() / 255.0
        processed_tensor = processed_tensor.unsqueeze(0)
    
    return processed_tensor,processed_image

# def process_yolo_results(image, yolo_results):
#     """
#     Process YOLO results for the vessel segmentation pipeline
#     """
#     # If YOLO returns segmentation masks and they exist
#     try:
#         # Try accessing masks directly for newer YOLO versions
#         if hasattr(yolo_results, 'masks') and yolo_results.masks is not None:
#             mask = yolo_results.masks.data[0].cpu().numpy()
#             processed_image = image * mask[:, :, None]
#         # For older YOLO versions or different return formats
#         elif isinstance(yolo_results, list) and len(yolo_results) > 0:
#             if hasattr(yolo_results[0], 'masks') and yolo_results[0].masks is not None:
#                 mask = yolo_results[0].masks.data[0].cpu().numpy()
#                 image = cv2.resize(image,(mask.shape[1],mask.shape[0]))
#                 processed_image = image * mask[:, :, None]
#             else:
#                 processed_image = image
#         else:
#             processed_image = image
#     except (AttributeError, IndexError) as e:
#         print(f"Warning: Could not extract mask from YOLO results: {e}")
#         processed_image = image
    
#     return processed_image

def process_yolo_results(image, yolo_results):
    """
    Process YOLO results for the vessel segmentation pipeline
    """
    processed_image = image  # fallback if no mask
    try:
        # Newer YOLO versions
        if hasattr(yolo_results, 'masks') and yolo_results.masks is not None:
            mask = yolo_results.masks.data[0].cpu().numpy()
            if len(mask.shape) == 2:
                mask = mask[:, :, None]  # Expand dimensions
            processed_image = image * mask
        
        # Older YOLO formats
        elif isinstance(yolo_results, list) and len(yolo_results) > 0:
            if hasattr(yolo_results[0], 'masks') and yolo_results[0].masks is not None:
                mask = yolo_results[0].masks.data[0].cpu().numpy()
                if len(mask.shape) == 2:
                    mask = mask[:, :, None]
                # Optional: resize image to match mask size if needed
                if (image.shape[0], image.shape[1]) != (mask.shape[0], mask.shape[1]):
                    image = cv2.resize(image, (mask.shape[1], mask.shape[0]))
                processed_image = image * mask
    except (AttributeError, IndexError, ValueError) as e:
        print(f"Warning: Could not extract or apply mask from YOLO results: {e}")

    return processed_image


def visualize_results(original_image, prediction, output_path, processed_image):
    """
    Visualize the segmentation results
    """
    # Resize prediction to match original image if needed
    if original_image.shape[:2] != prediction.shape:
        prediction = cv2.resize(
            prediction.astype(np.uint8), 
            (original_image.shape[1], original_image.shape[0]),
            interpolation=cv2.INTER_NEAREST
        )
    
    output_dir = './results'
    os.makedirs(output_dir, exist_ok=True)
    cv2.imwrite(f"{output_dir}/original.png", original_image)
    cv2.imwrite(f"{output_dir}results/sclera.png", processed_image)
    cv2.imwrite(f"{output_dir}results/vessel.png", prediction)
    
    fig, axes = plt.subplots(1, 3, figsize=(12, 6))
    # Original image
    axes[0].imshow(original_image)
    axes[0].set_title("Original Image")
    axes[0].axis('off')
    
    # Predicted mask
    axes[1].imshow(processed_image, cmap='gray')
    axes[1].set_title("yolo Segmentation")
    axes[1].axis('off')

    # Predicted mask
    axes[2].imshow(prediction, cmap='gray')
    axes[2].set_title("Vessel Segmentation")
    axes[2].axis('off')
    
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    print(f"Visualization saved to {output_path}")
    
    # Also save the mask separately as a binary image
    mask_path = output_path.replace('.png', '_mask.png')
    cv2.imwrite(mask_path, (prediction * 255).astype(np.uint8))
    print(f"Binary mask saved to {mask_path}")

def process_and_show_image(image, mask, mean=0.007223172757845297):
    if image is None:
        raise ValueError("Input image is None")
    if mask is None:
        raise ValueError("Input mask is None")

    # Resize mask to match image dimensions
    resized_mask = cv2.resize(mask, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_NEAREST)

    # Ensure mask is binary (0 or 1)
    _, binary_mask = cv2.threshold(resized_mask, 127, 1, cv2.THRESH_BINARY)

    # Apply mask to the image
    masked_image = (image * binary_mask[:, :, np.newaxis]).astype(np.uint8)

    # Extract red channel and compute average red intensity
    red_channel = masked_image[:, :, 2]
    normalized_red_channel = red_channel / 255.0
    avg_red_intensity = np.mean(normalized_red_channel)

    if avg_red_intensity>=mean:
        redness_type="high redness"
    else: 
        redness_type="low redness"

    # Show results
    plt.figure(figsize=(15, 5))

    # Original image
    plt.subplot(1, 3, 1)
    plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    plt.title("Original Image")
    plt.axis("off")

    # Mask
    plt.subplot(1, 3, 2)
    plt.imshow(mask, cmap="gray")
    plt.title("Mask")
    plt.axis("off")

    # Masked image with intensity title
    plt.subplot(1, 3, 3)
    plt.imshow(cv2.cvtColor(masked_image, cv2.COLOR_BGR2RGB))
    plt.title(f"Avg Red Intensity: {avg_red_intensity:.4f}, {redness_type}")
    plt.axis("off")

    plt.savefig('./redness.png')



def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Vessel Segmentation Inference')
    # parser.add_argument('--image', type=str, required=True, help='Path to input image')
    # parser.add_argument('--image', type=str, required=True, help='Path to input image')
    # parser.add_argument('--yolo_model', type=str, required=True, help='Path to trained YOLO model')
    # parser.add_argument('--unet_model', type=str, required=True, help='Path to trained U-Net model')
    parser.add_argument('--output', type=str, default='output.png', help='Path to save output visualization')
    parser.add_argument('--input_size', type=int, default=512, help='Input size for model')
    args = parser.parse_args()
    yolo_weights = './assets/best.pt'
    # parser.add_argument('--unet_model', type=str, required=True, help='Path to trained U-Net model')
    unet_weights = './assets/vein.pth'
    img = './Sample_Images/1.jpg'
    # /run/user/1000/gvfs/sftp:host=10.8.1.102,user=shagun/storage/shagun/pipeline/Sample_Images
    # Check if image exists
    if not os.path.exists(img):
        print(f"Error: Image file not found at {img}")
        return
    
    # Check if output directory exists, create if not
    output_dir = os.path.dirname(args.output)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)
        print(f"Created output directory: {output_dir}")
    
    # Check for GPU availability
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Load models
    print("Loading YOLOv8 model...")
    yolo_model = YOLO(yolo_weights)
    
    print("Loading U-Net model...")
    unet_model = load_model(checkpoint_path=unet_weights, device=device)
    unet_model.eval()
    
    # Read original image for visualization
    original_image = cv2.imread(img)
    original_red = cv2.imread(img, cv2.IMREAD_COLOR)
    original_image = cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB)
    
    # test = cv2.imread('2.jpg', cv2.IMREAD_COLOR)
    # tstm =  cv2.imread('2.png', cv2.IMREAD_COLOR)
    # Preprocess image with YOLO model
    print("Preprocessing image with YOLOv8 model...")
    processed_tensor,processed_image = preprocess_image(img, yolo_model, input_size=args.input_size)
    
    # Run inference with U-Net model
    print("Running vessel segmentation with U-Net model...")
    with torch.no_grad():
        processed_tensor = processed_tensor.to(device, dtype=torch.float32)
        prediction = unet_model(processed_tensor)
        prediction = torch.sigmoid(prediction)
        prediction = (prediction.cpu().numpy()[0, 0] > 0.5).astype(np.uint8)
    
    # Visualize and save results
    print("Generating visualization...")
    # visualize_results(original_image, prediction, args.output,processed_image)

    # process_and_show_image(test,tstm)
    import subprocess

    # Simple call, waits for completion
    subprocess.call(['python', 'AnglePred/src/main.py'])
    result = subprocess.run(
    ['python', 'AnglePred/src/main.py'],
    capture_output=True,
    text=True
    )
    print('angle_result ',result.stdout)  # output from other_script.py



    print("Vessel segmentation completed successfully!")


if __name__ == "__main__":
    main()