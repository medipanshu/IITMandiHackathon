def process_image(image_path):
    import cv2
    import json
    import numpy as np

    # Load the image
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError("Image not found or unable to load.")

    # Perform image processing (example: convert to grayscale and extract features)
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    height, width = gray_image.shape
    mean_intensity = np.mean(gray_image)

    # Prepare the JSON output
    result = {
        "image_path": image_path,
        "dimensions": {
            "height": height,
            "width": width
        },
        "mean_intensity": mean_intensity
    }

    return json.dumps(result)